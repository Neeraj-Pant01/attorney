export const Service = [
    {
        id:"1",
        title:"Sexual offences",
        img:"/assets/crimes/offence.svg"
    },
    {
        id:"2",
        title:"Bail",
        img:"/assets/crimes/bail.svg"
        
    },
    {
        id:"3",
        title:"Internet Crime",
        img:"/assets/crimes/internet-crime.svg"
    }
]

export const AddServices = [
    {
        id:"4",
        title:"Domestic offences",
        img:"/assets/crimes/domesticVoilence"
    },
    {
        id:"5",
        title:"Firearms & Weapons"
    },
    {
        id:"6",
        title:"Assault & Threats"
    },
    {
        id:"7",
        title:"Property,Fraud & Theft"
    },
    {
        id:"8",
        title:"Appeals"
    },
    {
        id:"9",
        title:"Drugs Offences"
    },
    {
        id:"10",
        title:"Youth Charges"
    }
]