import MainPage from './components/MainPage';
import ReactJoyride from 'react-joyride';

function App() {
  return (
    <MainPage />
  );
}

export default App;
