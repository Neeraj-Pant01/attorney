import React from 'react'
import { useState } from 'react'
import "./login.css"
import LoginFooter from './loginFotter/LoginFooter'
import Otp from './otp/Otp'

const Login = () => {
    const [showOtp, setShowOtp] = useState(false);
    const sendOtp = (otp) =>{
        setShowOtp(true)
    }
  return (
    <div className='login'>
        <div className='login-cont'>
            <div className='login-img'>
                <div className='login-logo'>
                    <div className='logo'>
                        <img src='/assets/loginLogo.svg' alt='logo' className='logo-img'></img>
                    </div>
                    <div className='login-box'>
                        <h1 className='LOG-IN'>LOG IN</h1>
                    </div>
                </div>
                <Otp showOtp={showOtp} setShowOtp={setShowOtp}/>
            </div>
            <div className='sign-up-wrapper'>
            <div className='signup-form'>
                <div className='mobile'>
                    <div className='mobile-radio'>
                    <input type="radio" checked="checked" className='radio-btn' name='mobile'></input><p className='radio-name'>Mobile no</p>
                    </div>
                    <div className='login-input-field'>
                    <input type="text" placeholder='enter mobile number'></input>
                </div>
                </div>
                <div className='name'>
                <div className='mobile-radio'>
                    <input type="radio" checked="checked" className='radio-btn' name='name'></input><p className='radio-name'>Name</p>
                    </div>
                    <div className='login-input-field'>
                    <input type="text" placeholder='enter name'></input>
                </div>
                </div>
                <div className='signUp'>
                    <div className='sign-up-btn-wrapper'>
                        <button className='signup-btn' onClick={sendOtp}>Sign up</button>
                    </div>
                    <div className='signup-info-box'>
                        <input type="checkbox"></input>
                        <p className='t-c'>i agree terms & conditions <br></br> already registered ? login</p>
                    </div>
                </div>
            </div>
            </div>
            <div className='vision'>
                <div className='vision-mission-img'>
                    <img src='/assets/bulb.svg' alt='bulb'></img>
                </div>
                <div className='vision-mission-title'>
                    <h1>OUR VISION</h1>
                    <hr className='vision-mission-hr'></hr>
                </div>
                <div className='vision-mission-info'>
                    <p>Our advocates strives to be a multi skill knowledge based law firm, driven by ethics and human values, delevering excellence and value in the field of legal service</p>
                </div>
            </div>
            <div className='mission'>
                <div className="mission-img">
                    <img src='/assets/missionimg.svg' alt='mission'></img>
                </div>
                <div className='mission-title'>
                    <h1>OUR MISSION</h1>
                    <hr className='vision-mission-hr'></hr>
                </div>
                <div className='m-info'>
                    <p>Our mission is to be the most preffered law firm within the indiam market, providing:</p>
                    <p>Clients with qualitative and innovative professional advice in atime bound and cost effective manner</p>
                    <p>Attorneys with a conductive environment for all ground growth and deveopment</p>
                </div>
            </div>
        </div>
        <LoginFooter />
    </div>
  )
}

export default Login
