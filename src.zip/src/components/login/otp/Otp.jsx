import React from 'react'
import "./otp.css"
import { Link } from 'react-router-dom'

const Otp = ({showOtp, setShowOtp}) => {
  const closeOptp = () =>{
    setShowOtp(false)
  }
  return (
    <div className={!showOtp ? 'hide' : 'send-otp'}>
    <div className="opt-img">
      <button className='L-BTN-C' onClick={closeOptp}>X</button>
        <img src="/assets/loginLogo.svg" alt="login"></img>
        <h1 className="otp-info">Consult lawers online instantly with the online atterny</h1>
      </div>
      <div className="otp-details">
        <div className="enter-otp">
          <div className="enter-otp-info">
          <h2 className='ENTER-OTP'>Enter OTP</h2>
          </div>
          <div className="enter-otp-info">
          <p className="desc">OTP has been sent to your mobile number 916754903765 <a href="#">edit</a></p>
          </div>
          {/* <div className="enter-otp-info"> */}
            <p className="otp-header">Enter OTP</p>
        </div>
        <div className="fill-otp">
          <div className="otp-fields">
            <input type="text" maxlength = "1"></input>
            <input type="text" maxlength = "1"></input>
            <input type="text" maxlength = "1"></input>
            <input type="text" maxlength = "1"></input>
          </div>
          <button className="verify-otp"> <Link to="/documents">verify-OTP</Link></button>
        </div>
      </div>
    </div>
  )
}

export default Otp
