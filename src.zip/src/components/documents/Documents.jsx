import React from 'react'
import { useState } from 'react'
import DocsOtp from './DocsOtp'
import "./documents.css"
import {CgProfile} from "react-icons/cg"
import {HiOutlineIdentification} from "react-icons/hi"
import {HiIdentification} from "react-icons/hi"
import {AiFillCamera} from "react-icons/ai"

const Documents = () => {
  const [value, setValue] = useState(false)

  const open = () =>{
    setValue(true)
  }
  return (
    <>
    <div className='documents-wrapper'>
      <div className={value ? 'docs-otp-wrapper' : 'docs-otp-hide'}>
        <DocsOtp setValue = {setValue} value={value} />
      </div>
      <div className='documents-cont'>
        <div className='documents-bg-img'>
          <img src='/assets/logo2.svg' alt='logo'></img>
        </div>
        <div className='submit-docs'>
          <div className='submit-docs-title-box'>
            <b> SUBMIT DOCUMENTS</b><hr></hr>
            <p>we need to verify your information please submit your documents below to sign up</p>
            <div className='personal-details-title'>
              <span style={{display:"flex", alignItems:"center"}}> <CgProfile style={{color:"#ffcd6c", fontSize:"1.7rem"}}/> Personal Details</span>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div className='personal-details-wrapper'>
      <div className='profile-dp-box'>
        <AiFillCamera className='AiFillCamera' style={{position:"absolute",borderRadius:"50%",backgroundColor:"grey",padding:".5rem",fontSize:"1.5rem",color:"white"}}/>
      </div>
      <div className='personal-detail-form'>
        <label><b>Full Name</b></label><br></br>
        <input type="text" placeholder="Name"></input><br></br>

        <label><b>Email Id</b></label><br></br>
        <input type="text" placeholder="Email Id"></input><br></br>

        <label><b>Number</b></label><br></br>
        <input type="text" placeholder="Number"></input><br></br>

        <label><b>Date Of Birth</b></label><br></br>
        <input type="date" placeholder="Date Of Birth"></input><br></br>

        <label><b>City</b></label><br></br>
        <input type="text" placeholder="City"></input><br></br>

        <div className='state-zip'>
          <div className='state'>
          <label><b>State</b></label><br></br>
          <input type="text" placeholder="State"></input><br></br>
          </div>
          <div className='zip'>
          <label><b>Zip Code</b></label>
          <input type="text" placeholder="Zip code"></input>
          </div>
        </div>

        <div className='gender-wrapper'>
          <label>Gender</label><br></br>
          <div className='gender'>
          <input type="text" value="Male" ></input>
          <input type="text" value="Female" contentEditable="no"></input>
          </div>
        </div>
      </div>
    </div>

    <div className="kyc-wrapper">
      <div className='kyc'>
        <div className='licence'>
          <p> <HiOutlineIdentification style={{color:"goldenrod"}} /> Advocate Licence verification</p><br></br>
          <span>upload both side photo of your Advocate license</span><br></br>
          <input type="file" id='upload' name="upload"></input>
        </div>
        <div className='kyc-verify'>
          <p> <HiIdentification style={{color:"goldenrod"}}/> KYC verification</p>
          <div className='kyc-verify-adhar-p'>Adhar Card Number</div>
          <input type="text" placeholder='Enter your Adhar card Number'></input>
        </div>
        <button className='kyc-btn' onClick={open}>SIGN UP</button>
      </div>
    </div>
    </>
  )
}

export default Documents
