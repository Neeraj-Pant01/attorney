import React, { useState } from 'react'
import "./serviceSidebar.css"
// import { Service, AddServices } from '../../ServiceData'

const ServiceSidebar = ({comp1,setComp1,comp2,setComp2,comp3,setComp3,comp4,setComp4,comp5,setComp5,comp6,setComp6,comp7,setComp7,setShowbar}) => {
  // const [comp1, setComp1] = useState(true);
  // const [comp2, setComp2] = useState(true);
  // const [comp3, setComp3] = useState(true);
  // const [comp4, setComp4] = useState(true);
  // const [comp5, setComp5] = useState(true);
  // const [comp6, setComp6] = useState(true);
  // const [comp7, setComp7] = useState(true);
  const handleClick = () =>{
    setShowbar(false)
  }
  return (
    <>
    <div className='my-services-wrapper'>
      <p>add services</p>
      <li><input type="checkbox" className='inp' checked="checked"></input><span className='M-Svs'>Sexual Offence</span></li>

      <li><input type="checkbox" className='inp' checked="checked"></input><span className='M-Svs'>Bail</span></li>

      <li><input type="checkbox" className='inp' checked="checked"></input><span className='M-Svs'>Internet Crime</span></li>
      <li className={comp1 ? 'HDN' : 'SHOW'}><input type="checkbox" className='inp' checked="checked"></input><span className='M-Svs'>Domestic Offences</span></li>
      <li className={comp2 ? 'HDN' : 'SHOW'}><input type="checkbox" className='inp' checked="checked"></input><span className='M-Svs'>Firearm & Weapons</span></li>
      <li className={comp3 ? 'HDN' : 'SHOW'}><input type="checkbox" className='inp' checked="checked"></input><span className='M-Svs'>Assaults & Threats</span></li>
      <li className={comp4 ? 'HDN' : 'SHOW'}><input type="checkbox" className='inp' checked="checked"></input><span className='M-Svs'>Property, Fraud & Theafts</span></li>
      <li className={comp5 ? 'HDN' : 'SHOW'}><input type="checkbox" className='inp' checked="checked"></input><span className='M-Svs'>Appeals</span></li>
      <li className={comp6 ? 'HDN' : 'SHOW'}><input type="checkbox" className='inp' checked="checked"></input><span className='M-Svs'>Drugs Offences</span></li>
      <li className={comp7 ? 'HDN' : 'SHOW'}><input type="checkbox" className='inp' checked="checked"></input><span className='M-Svs'>Youth Charges</span></li>
      
    </div>
    <div className='ADD-SERVICES-CONT'>
    <p>add more services</p>
    <li className={!comp1 ? 'HDN' : 'SHOW'}><input type="checkbox" className='INP' onChange={(e)=>setComp1(false)}></input><span className='MA-Svs'>Domestic Offences</span>s</li>
    <li className={!comp2 ? 'HDN' : 'SHOW'}><input type="checkbox" className='INP' onChange={(e)=>setComp2(false)}></input><span className='MA-Svs'>Firearm & Weapons</span></li>
    <li className={!comp3 ? 'HDN' : 'SHOW'}><input type="checkbox" className='INP' onChange={(e)=>setComp3(false)}></input><span className='MA-Svs'>Assault & Threats</span></li>
    <li className={!comp4 ? 'HDN' : 'SHOW'}><input type="checkbox" className='INP' onChange={(e)=>setComp4(false)}></input><span className='MA-Svs'>Property, Fraud & Theaft</span></li>
    <li className={!comp5 ? 'HDN' : 'SHOW'}><input type="checkbox" className='INP' onChange={(e)=>setComp5(false)}></input><span className='MA-Svs'>Appeals</span></li>
    <li className={!comp6 ? 'HDN' : 'SHOW'}><input type="checkbox" className='INP' onChange={(e)=>setComp6(false)}></input><span className='MA-Svs'>Drugs Offences</span></li>
    <li className={!comp7 ? 'HDN' : 'SHOW'}><input type="checkbox" className='INP' onChange={(e)=>setComp7(false)}></input><span className='MA-Svs'>Youth Charges</span></li>
      <button className='DONE' onClick={handleClick}>Done</button>
    </div>
    </>
  )
}
export default ServiceSidebar
