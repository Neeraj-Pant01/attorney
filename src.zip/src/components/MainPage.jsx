import React from 'react'
import {Routes, Route} from "react-router-dom";
import Login from "./login/Login"
import CustomerSupport from './customer-support/CustomerSupport'
import Firm from './firm/Firm'
import Payments from './payments/Payments'
import YourServices from './myServices/YourServices'
import Services from './myServices/Services'
// import Notificatio from './Notifiction/Notificatio'
import Review from './reviews/Review'
import MyWallet from './Wallet/MyWallet'
import VideoCall from './call/calling/VideoCall'
// import Oncall from './call/Oncall'
import Calling from './call/calling/Calling'
import Chats from './chats/Chats'
import Lawers from './lawers/Lawers'
import Documents from './documents/Documents'
import UserInfo from './lawers/UserInfo';
import EditProfile from './EditProfile/EditProfile';
import MobCard from './lawers/MobCard';
const MainPage = () => {
  return (
    <>
    <Routes>
      <Route path='/' element={<Login />} />
      <Route path='/appointment' element={<Lawers />} />
      <Route path='/reviews' element={<Review />} />
      <Route path='/services' element={<Services />} />
      <Route path='/payments' element={<Payments />} />
      <Route path='/help' element={<CustomerSupport />} />
      <Route path='/videocall' element={<VideoCall />} />
      <Route path='/about' element={<Firm />} />
      <Route path='/documents' element={<Documents />} />
      <Route path='/wallet' element={<MyWallet />} />
      <Route path='/yourservices' element={<YourServices />} />
      <Route path='/userinfo' element={<UserInfo />} />
      <Route path='/chats' element={<Chats />} />
      <Route path='/call' element={<Calling />} />
      <Route path='/editprofile' element={<EditProfile />} />
      <Route path='/card' element={<MobCard />} />
    </Routes>
    </>
  )
}

export default MainPage
