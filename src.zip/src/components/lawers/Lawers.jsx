import React, { useState } from 'react'
import Sidebar from './Sidebar'
import Topbar from './Topbar'
import "./css/lawers.css"
import Card from './Card'
import InfoCard from './InfoCard'
import UserInfo from './UserInfo'

const Lawers = () => {
  const [accept, setAccept] = useState(false);
  const [info, setInfo] = useState(false)
  console.log(info)

const testFunc = () =>{
  setAccept(true)
}

  return (
    <>
    <div className='cards bg-hide'>
      <Card />
    </div>
    <div className='lawers'>
      <Topbar />
      <div className='SIDEBAR'>
      <Sidebar />
      </div>
      <div className='lawers-wrapper'>
        <div className='lawers-container'>
              <div className='help-box'></div>
          <div className='lawers-info'>
            <div className='lawer-card'>
            <div className='p'>
            <p className='welcome-lawer'>welcome back !</p>
            <h1 className='users-name'>Mr XYZ</h1>
            </div>
              <div className='cards'>
              <Card info={info} setInfo={setInfo} accept={accept} testFunc={testFunc}/>
              <Card />
              <Card />
              <Card />
              <Card />
              <Card />
              <Card />
              <Card />
              </div>
            </div>
            <div className='card-info'>
              {!info ? <InfoCard /> : <UserInfo accept={accept} testFunc={testFunc} />}
            </div>
          </div>
        </div>
      </div>
    </div>
    </>
  )
}

export default Lawers
