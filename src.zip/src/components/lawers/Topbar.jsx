import React from 'react'
import "./css/topbar.css"
import {FiMail} from "react-icons/fi"
import {BsBell} from "react-icons/bs"
import { BsSearch } from 'react-icons/bs'
const Topbar = () => {
  return (
    <div className='topbar-wrapper'>
          <div className='topbar'>
      <div className='topbar-logo'>
        <img src='/assets/logo2.svg' alt='logo'></img>
      </div>
      <div className='topbar-searchbar'>
        <input type="text" placeholder="Search..."></input><BsSearch className='search-icon'/>
      </div>
      <div className="topbar-icons">
        <FiMail className='icon' />
        <BsBell className="icon"/>
        <span className='profile-img'>
          <img src='/assets/profile-img.svg' alt='profile-img'></img>
        </span>
      </div>
    </div>
    </div>
  )
}

export default Topbar
