import React from 'react'
import Sidebar from '../lawers/Sidebar'
import Topbar from '../lawers/Topbar'
import "./editprofile.css"
import MobEditProfile from './MobEditProfile'

const EditProfile = () => {
  return (
    <>
    <div className='editprofile'>
        <Topbar />
        <Sidebar />
        <div className='editprofile-cont'>
            <div className='editprofile-wrapper'>
              <h1 className='editprofile-title'>Edit Profile</h1>
              <div className='PROFILE-IMAGE-CONT'>
                <div className='PROFILE-IMAGE'>
                  {/* <img src='/assets/calls/person1.svg' alt='person'></img> */}
                </div>
                </div>
                <form className='EDIT-PROFILE-FORM'>
                  <div className='e-p-f'>
                    <h2 className='FORM-I-TITLE'>Name</h2>
                    <input className='e-p-f-i' type="text"></input>
                  </div>
                  <div className='e-p-f'>
                    <h2 className='FORM-I-TITLE'>Email</h2>
                    <input className='e-p-f-i' type="text"></input>
                  </div>
                  <div className='e-p-f'>
                    <h2 className='FORM-I-TITLE'>Number</h2>
                    <input className='e-p-f-i' type="text"></input>
                  </div>
                  <div className='e-p-f'>
                    <h2 className='FORM-I-TITLE'>City</h2>
                    <input className='e-p-f-i' type="text"></input>
                  </div>

                  <div className='s-z-f'>
                    <div className='c-e-f'>
                    <h2 className='FORM-I-TITLE'>State</h2>
                    <input className='e-f' type="text"></input>
                    </div>
                    <div className='c-e-f'>
                    <h2 className='FORM-I-TITLE'>Zip Code</h2>
                    <input className='e-f' type="text"></input>
                    </div>
                  </div>

                  {/* <h2 className='FORM-I-TITLE'>Gender</h2> */}
                  <div className='M-F-f'>
                    <div className='GENDER-f'>
                    <input className='MALE' value="Male" type="text"></input>
                    </div>
                    <div className='GENDER-f'>
                    <input className='FEMALE' value="Female" type="text"></input>
                    </div>
                  </div>

                  <div className='e-p-f BIO-CONT'>
                    <h2 className='FORM-I-TITLE'>Bio</h2>
                    <textarea className='BIO' rows={10} cols={10} placeholder="write here.."></textarea>
                  </div>

                  <div className='e-p-f-b'>
                    <button className='SAVE'>SAVE</button>
                  </div>
                </form>
            </div>
        </div>
    </div>
    <MobEditProfile />
    </>
  )
}

export default EditProfile
